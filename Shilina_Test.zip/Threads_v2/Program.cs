﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Linq;

namespace Threads_v2
{
    class Program
    {
        static string text = "";
        static string[] words;

        static async Task<string> ReadAsync(string path)
        {
            // асинхронное чтение из файла
            using (StreamReader reader = new StreamReader(path))
            {
                string result = await reader.ReadToEndAsync();
                return result;
            }
        }

        static Dictionary<string, int> mergeDict(in Dictionary<string, int> dict1, in Dictionary<string, int> dict2)
        {
            //возвращаем словарь триплетов с суммой счетчиков
            return dict1.Concat(dict2).GroupBy(x => x.Key).ToDictionary(x => x.Key, x => x.Sum(y => y.Value));
        }

        static async Task Main(string[] args)
        {
            bool acces = false;
            while (!acces)
            {
                //путь до текстового файла
                Console.WriteLine("Введите путь до файла или нажмите 1 для тестового примера");
                string path = Console.ReadLine();
                if (path == "1")
                {
                    path = @"../../../test.txt";
                    acces = true;
                }
                try
                {
                    //весь текст из файла
                    text = await ReadAsync(path);
                    acces = true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("Путь до файла некорректный");

                }
            }
            //запускаем время
            var timer = new Stopwatch();
            timer.Start();
            //отделяем слова
            words = Regex.Matches(text, @"[А-Яа-яЁёA-Za-z]+").Cast<Match>()
                .Select(m => m.Value).ToArray();

            if (words.Length == 0)
            {
                Console.WriteLine("Файл пустой");
                return;
            }

                //словари триплеты-счетчики
                List<Dictionary<string, int>> myList = new List<Dictionary<string, int>>();
            int numTsks = 1;
            int numWordsOnTask = 1;
            try
            {
                numTsks = (int)Math.Log(words.Length); //кол-во потоков
                numWordsOnTask = words.Length / numTsks; //сколько слов обработать одному потоку
            }
            catch (Exception e)
            {
                Console.WriteLine("Текст содержит меньше 10 триплетов или мало слов");
                numTsks = 1;
                numWordsOnTask = words.Length;
            }
            
            var tasks = new Task[numTsks];

            //всего numTsks потоков
            for (int i = 0; i < numTsks; i++)
            {
                int f = i;
                //локальный словарь для одного потока
                Dictionary<string, int> tripInTask = new Dictionary<string, int>();

                tasks[f] = new Task(() =>
                {
                    //делим количество слов на равные промежутки по количеству потоков
                    for (int currentWord = f * numWordsOnTask; currentWord < (f + 1) * numWordsOnTask; currentWord++)
                    {
                        //выбираем из одного слова все триплеты
                        oneWord(words[currentWord], ref tripInTask);
                    }
                    //сохраняем найденные триплеты в глобальной переменной
                    myList.Add(tripInTask);
                });
            }
            //запускаем потоки
            foreach (var t in tasks)
            {
                t.Start();
            }
            Task.WaitAll(tasks);

            //обрабатываем остаток слов после деления
            Dictionary<string, int> tripExtra = new Dictionary<string, int>();
            for (int f = numTsks * numWordsOnTask; f < words.Length; f++)
            {
                oneWord(words[f], ref tripExtra);
            }
            myList.Add(tripExtra);

            //сливаем все словари в один
            Dictionary<string, int> tripAll = new Dictionary<string, int>();
            foreach (var v in myList)
            {
                tripAll = mergeDict(tripAll, v);
            }

            if (tripAll.Count == 0)
            {
                Console.WriteLine("Триплетов не обнаружено");
                return;
            }
            
            //вывод топ 10 триплетов
            var myListTop = tripAll.ToList();
            myListTop.Sort((pair1, pair2) => pair1.Value.CompareTo(pair2.Value));

            if (myListTop.Count < 10)
            {
                for (int i = myListTop.Count - 1; i > 0; i--)
                {
                    Console.Write("{0}, ", myListTop[i].Key);
                }
                Console.WriteLine("{0}", myListTop[0].Key);
            }
            else { 
                for (int i = myListTop.Count - 1; i > myListTop.Count - 10; i--)
                {
                    Console.Write("{0}, ", myListTop[i].Key);
                }
                Console.WriteLine("{0}", myListTop[myListTop.Count - 10].Key);
            }


            //считаем и выводим время
            timer.Stop();
            TimeSpan timeTaken = timer.Elapsed;
            string GetTime = "Потрачено милисекунд: " + timeTaken.ToString(@"fff");
            Console.WriteLine(GetTime);
            Console.ReadKey();
        }

        static void oneWord(string word, ref Dictionary<string, int> tripOnTask)
        {
            if (word.Length > 2) //ищем только триплеты
            {
                int i = 0;
                while (i <= word.Length - 3)
                {
                    try
                    {
                        //либо увеличиваем счетчик
                        tripOnTask[word.Substring(i, 3)] += 1;
                    }
                    catch
                    {
                        //либо добавляем триплет
                        tripOnTask[word.Substring(i, 3)] = 1;
                    }
                    i++;
                }
            }
        }
    }
}
